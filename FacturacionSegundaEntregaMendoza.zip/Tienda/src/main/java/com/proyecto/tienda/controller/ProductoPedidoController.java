package com.proyecto.tienda.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/productopedido")
public class ProductoPedidoController {

}
