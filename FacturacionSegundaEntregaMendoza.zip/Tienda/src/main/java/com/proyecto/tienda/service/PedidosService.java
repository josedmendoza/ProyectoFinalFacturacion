package com.proyecto.tienda.service;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyecto.tienda.entity.Pedidos;
import com.proyecto.tienda.repository.PedidosRepository;

@Service
public class PedidosService {
	
	@Autowired
	private final PedidosRepository pedidosRepository;
	
    
	public PedidosService(PedidosRepository pedidosRepository, FechaRestApi fechaRestApi) {
		this.pedidosRepository = pedidosRepository;
	}

	@Autowired
	private FechaRestApi fechaRestApi;

	public LocalDate getFecha() {
		String response =  fechaRestApi.getFecha();
		
		//Formatea respuesta en pares para obtener el valor de la dateTime
		String[] lines = response.split("\n");
		Map<String, String> keyValueMap = new HashMap<>();

		for (String line : lines) {
		    String[] parts = line.split(": ", 2);
		        if (parts.length == 2) {
		            keyValueMap.put(parts[0], parts[1]);
		        }
		    }
		String datetimeValue = keyValueMap.get("datetime");

		datetimeValue = datetimeValue.replace(" ", "");

		// Ajustar el patrón para incluir espacio en blanco y el offset con dos puntos
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSSXXX");
		LocalDate localDate = LocalDate.parse(datetimeValue, formatter);
		
		return localDate;
	}
	
	//Metgrodo para crear el comprobante del pedido
	public Pedidos crearComprobante (Pedidos pedido ) {
		return pedidosRepository.save(pedido);
		
	}
	

}
