package com.proyecto.Tienda;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


//Con la anotacion @Entity se crea la entidad
@Entity
@Table(name = "CLIENTE")
public class Cliente {
	
	//Con la anotacion  @Id se define la llave primaria y con la anotacion @Column el nombre de las columnas de la entidad
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idCliente;
	
	@Column(name = "NOMBRE")
	private String nombre;
	
	@Column(name = "APELLIDO")
	private String apellido;
	
	@Column(name = "DNI")
	private int dni;
	
	@Column(name = "EDAD")
	private int cantidad_años;
	
	//Se realiza la relacion OneToMany con la entidad Pedidos

	@OneToMany(mappedBy = "cliente")
	 List<Pedidos> listapedidos;
	
	// Se generan los constructores
	public Cliente() {}


	public Cliente(int id, String nombre, String apellido, int dni, int cantidad_años) {
		this.idCliente = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.dni = dni;
		this.cantidad_años = cantidad_años;
	}

	//Se generan los metodos getter y setter y toString
	public int getId() {
		return idCliente;
	}


	public void setId(int id) {
		this.idCliente = id;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getApellido() {
		return apellido;
	}


	public void setApellido(String apellido) {
		this.apellido = apellido;
	}


	public int getDni() {
		return dni;
	}


	public void setDni(int dni) {
		this.dni = dni;
	}


	public int getCantidad_años() {
		return cantidad_años;
	}


	public void setCantidad_años(int cantidad_años) {
		this.cantidad_años = cantidad_años;
	}


	@Override
	public String toString() {
		return "Cliente [id=" + idCliente + ", nombre=" + nombre + ", apellido=" + apellido + ", dni=" + dni
				+ ", cantidad_años=" + cantidad_años + "]";
	}



}
