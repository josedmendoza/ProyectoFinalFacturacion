package com.proyecto.Tienda;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

//Con la anotacion @Entity se crea la entidad

@Entity
@Table(name = "PRODUCTOPEDIDO")
public class ProductoPedido {
	
	//Con la anotacion  @Id se define la llave primaria y con la anotacion @Column el nombre de las columnas de la entidad

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int productoPedidoID;
	
	@Column(name = "CANTIDAD")
	private int cantidad;

	//Se realiza la relacion ManyToOne entre las entidaddes producto y pedidos
	@ManyToOne
    @JoinColumn(name = "pedidoId")
	Pedidos pedidoP;
	
	@ManyToOne
	@JoinColumn(name = "productoId")
	Producto productoP;
	
	
	// Se generan los constructores

	public ProductoPedido() {
	}

	public ProductoPedido(int productoPedidoID, Pedidos pedido, Producto producto, int cantidad) {
		this.productoPedidoID = productoPedidoID;
		this.pedidoP = pedido;
		this.productoP = producto;
		this.cantidad = cantidad;
	}

	//Se generan los metodos getter y setter y toString

	public int getProductoPedidoID() {
		return productoPedidoID;
	}

	public void setProductoPedidoID(int productoPedidoID) {
		this.productoPedidoID = productoPedidoID;
	}

	public Pedidos getPedido() {
		return pedidoP;
	}

	public void setPedido(Pedidos pedido) {
		this.pedidoP = pedido;
	}

	public Producto getProducto() {
		return productoP;
	}

	public void setProducto(Producto producto) {
		this.productoP = producto;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	@Override
	public String toString() {
		return "ProductoPedido [productoPedidoID=" + productoPedidoID + ", pedido=" + pedidoP + ", producto=" + productoP
				+ ", cantidad=" + cantidad + "]";
	}
	
	
}
