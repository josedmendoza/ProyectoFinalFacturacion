package com.proyecto.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proyecto.service.PedidosService;

@RestController
@RequestMapping ("/pedido")
public class PedidoController {

	@Autowired
	private PedidosService pedidosService;
	
//	@GetMapping(value = "/idpedido", produces = (MediaType.APPLICATION_JSON_VALUE))
	@GetMapping(value = "/idpedido")
	public ResponseEntity <?> getFecha() {
		String obternerFecha = pedidosService.getFecha();
		return ResponseEntity.ok(obternerFecha);
	}
	
	@PostMapping(value = "/id")
	public ResponseEntity <?> postFecha() {
		String obternerFecha = pedidosService.getFecha();
		return ResponseEntity.ok(obternerFecha);
	}
}
