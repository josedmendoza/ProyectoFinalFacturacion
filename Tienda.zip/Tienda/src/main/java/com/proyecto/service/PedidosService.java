package com.proyecto.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyecto.entity.Pedidos;
import com.proyecto.repository.PedidosRepository;

@Service
public class PedidosService {
	
	@Autowired
	private final PedidosRepository pedidosRepository;
	
	public PedidosService(PedidosRepository pedidosRepository, FechaRestApi fechaRestApi) {
		this.pedidosRepository = pedidosRepository;
	}

	@Autowired
	private FechaRestApi fechaRestApi;

	public String getFecha() {
		return fechaRestApi.getFecha();
	}
	
	public Pedidos crearComprobante (long idPedido, Pedidos pedido ) {
		return pedidosRepository.save(pedido);
	}
	
	
	
	

}
