package com.proyecto.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


@Service
public class FechaRestApi {

	public String getFecha(){
		RestTemplate restTemplate = new RestTemplate();
		final String url = "http://worldtimeapi.org/api/ip";
		return restTemplate.getForObject(url, String.class);
	}
	
		 

	
}
